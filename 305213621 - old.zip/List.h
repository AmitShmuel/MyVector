// List Header file 
// List is implemented as a template of any T elements
// List holds an array of T elements, top and size values

#ifndef _LIST_
#define _LIST_
#include <iostream>
using namespace std;

const int SIZE = 10;
const int MAX_SIZE = 1024;

// some aid functions
int setSize(int);
void checkBounds(int , int);


template <class T>
class List{
	
	int top , size;
	T* Array;
	
public:
	
	List(int sz = SIZE) : size(setSize(sz)) , top(-1) , Array(new T[size]) {cout << "Construct List with " << size <<" elements..\n";}
	List(const List&);
	~List() {delete[] Array; cout << "Destruct List..\n";}
	
	List<T>& operator=(const List<T>&);
	T& operator[](int index);
	const T& operator[](int index) const;
	
	void clear();
	bool add(T elem);
	bool remove(int index);
	
	const T& first() const {checkBounds(0,top); return Array[0];} 
	const T& last() const {checkBounds(top,top); return Array[top];} 
	int getCount() const {return top+1;} 
	bool empty() const {return top == -1;} 
	bool full() const {return top == size-1;} 
};



template <class T>
List<T>::List(const List& l) : size(l.size) , top(l.top) , Array(new T[l.size]) {

	cout << "(Copy) Construct List..\n";
	for(int i=0; i<=top; ++i)
		Array[i] = l.Array[i]; 
}



template <class T>
List<T>& List<T>::operator=(const List<T>& l) {
	
	if(this == &l)
		return *this;
	
	if(size != l.size)	// if sizes are equal, allocation is not nesessary
	{
		delete[] Array;
		Array = new T[size=l.size];
	}
	
	for(int i=0; i<=l.top; ++i)
		Array[i] = l.Array[i];
	top = l.top;
	
	return *this;
}



template <class T>
T& List <T>::operator[](int index) {
	
	checkBounds(index,top);	
	return Array[index];
}



template <class T>
const T& List<T>::operator[](int index) const {
	
	checkBounds(index,top);
	return Array[index];
}



template <class T>
bool List <T>::add(T elem) {
	
	if(!full())
	{
		Array[++top] = elem;
		return true;
	}
		
	else
	{
		if(size == MAX_SIZE)
		{
			cout << "List has reached the maximum size, cannot allocate any more memory..\n";
			return false;
		}
		
		else
		{
			int toAlloc = (MAX_SIZE - size) > SIZE ? SIZE : (MAX_SIZE - size); 	// if the difference between size and MAX_SIZE is less than SIZE, allocates just the difference.. (aviod allocating more than 1024 = MAX_SIZE)
			
			T* newArray = new T[size+=toAlloc];	// Allocating a new larger array
			if(newArray == 0) 
			{
				cout << "List::add : Allocation error!\n\n"; 
				return false;
			}
		
			for(int i=0; i<=top; i++)	// copying each element to the new array
				newArray[i] = Array[i];
			
			delete[] Array;
		
			Array = newArray; 	// this Array points to the new array
			Array[++top] = elem;	// adding is possible..
		
			return true;
		}
	}
}



template <class T>
bool List <T>::remove(int index) {
	
	if(empty())
	{
		cout << "List is empty..\n";
		return false;
	}
	
	if(index < 0 || index > top)
	{
		cout << "There's not such index in the list..\n";
		return false;
	}
	
	if(getCount() == 1 || index == size-1)	// if list holds one element, or given index is the last index, we can do just top--
	{
		top--;
		return true;
	}
		
	while(index < top) {	// here we want to shift each element one cell back
		
		Array[index] = Array[index+1];
		index++;
	}
	--top;
	return true;		
}



template <class T>
void List<T>::clear() {
	
	if(empty()) 
	{
		cout << "List is empty..\n";
		return;
	}
	
	cout << "Clearing list..\n";
	
	if(full())
		size = SIZE;	// will allocate new list with defined SIZE
	else
		size -= top;	// will allocate new list with the remaining space
		
	delete[] Array;
	Array = new T[size];
	top = -1;
}

#endif
